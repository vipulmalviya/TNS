import React from 'react'

const SingleMoviePage = () => {
  return (
    <div>
      <h1>SingleMoviePage</h1>
    </div>
  )
}

export default SingleMoviePage
